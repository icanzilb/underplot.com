# Quick Start: dataTile for Mac

[dataTile for Mac](https://underplot.com/dataTile) is a developer tool for debugging apps on your Mac.

The Welcome window shows you recent apps you worked with and additional apps running in your Simulator.

![width=550 dataTile welcome window](welcome-max.png)

Click a recent app or "Add new app" to open a new one. Once you choose an app, dataTile starts monitoring its logs.

If it detects a log line that resembles a logged value like "`Offset: 340.0`" or "`Enabled = true`" dataTile automatically creates a tile to display that value over time:

![width=550 dataTile window](simple-window-info.png)

You can arrange your tiles to track multiple values over time and visualize them as text, charts, intervals, switches and more.

Depending on the data you log, dataTile can visualize an advance and complex UI to help your development workflow. 

![width=550 dataTile complex UI](multiple-light.png)

Enjoy the app!
