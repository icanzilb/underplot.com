# Quick Start: dataTile for Simulator

[dataTile for Simulator](https://apps.apple.com/app/datatile-for-simulator/id6444231603?l=en&mt=12) is a developer tool for debugging apps running in Xcode Simulator. 

The Welcome window shows you recent apps you worked with and additional apps running in your Simulator.

![width=550 dataTile welcome window](welcome-pro.png)

Click a recent app or "Add new app" to open a new one. Once you choose an app, dataTile starts monitoring its logs.

If it detects a log line that resembles a logged value like "`Offset: 340.0`" or "`Enabled = true`" dataTile automatically creates a tile to display that value over time:

![width=550 dataTile window](simple-window-info.png)

You can arrange your tiles to track multiple values over time and visualize them as text, charts, intervals, switches and more.

Any time you re-start your app in the Simulator, dataTile will reset all tiles automatically.

Depending on the data you log, dataTile can visualize an advance and complex UI to help your development workflow. 

![width=550 dataTile complex UI](multiple-light.png)

Enjoy the app!
