# Tracked in-app events

dataTile tracks anonymously a small list of usage events in an effort to 
figure out what's actually being useful for its users. These events are as follows:

- completing the app onboarding on first run.

- if the user has customized the capture groups during the onboarding.

- opening an article in the knowledge base.

- a user converts a tile to a custom regex tile.

- manually opening a new window from the File menu. 
