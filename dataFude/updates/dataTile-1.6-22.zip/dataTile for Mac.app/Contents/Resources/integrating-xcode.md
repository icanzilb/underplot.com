# Integrating in Xcode

While developing in Swift, you can make sure dataTile is always up
by leaving it to Xcode to keep the app running as long as you're debugging.

You can do this following these steps:

1. Open your Xcode project. Click `Project/Scheme/Edit Scheme...`

2. Click `In Run/Pre-actions/+` to add new pre-run script.

3. In the text field enter `open tile://new/[Your Process Name]` or `open tile-max://new/[Your Process Name]` depending on your dataTile version.

![width=550 bordered=1 Pre run-action configured to start Tile before running](pre-run-script.png)

4. Run your Xcode project like usual, the pre-run script will start or bring to front dataTile automatically.

> If you'd rather not add a pre-run action to your project scheme, you can [run dataTile manually](new.md) instead.  
