# Welcome to dataTile

![Tile window width=400](simple-window.png)

Welcome to the dataTile knowledge base.

Use the table of contents sidebar on the left hand side to explore topics.

To quickly find a topic use the search field at the bottom of the sidebar.
