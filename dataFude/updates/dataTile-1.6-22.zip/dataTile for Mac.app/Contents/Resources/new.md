# Observing a new app

You can use Tile not only with your own apps but with any app running in your Xcode Simulator 
that logs to Apple's unified logging system.

To manually start observing a currently running app do this:

1. Run Tile.app and click `File/Add new app...`.

![width=350 Adding a new app to observe](new-app.png)

2. In the dialogue enter the name of the app, for example "MyApp", "Weather", and so on.

3. dataTile opens a new window and shows any matching logs in tiles.
